import setup from "./modules/setup.js";
import bindEvents from "./modules/event.bindEvents.js";
import { elms } from "./modules/globals.js";
import suggestCache from "./modules/cache.js";
import destroy from "./modules/suggest.destroy.js";
import focus from "./modules/suggest.focus.js";
import disable from "./modules/suggest.disable.js";
import enable from "./modules/suggest.enable.js";
import { clearItems } from "./modules/item.js";
import {clearValues} from "./modules/suggest.clear.js";
import setValue from "./modules/suggest.setValue.js";
import update from "./modules/suggest.update.js";
import copy from "./modules/suggest.copy.js";
import paste from "./modules/suggest.paste.js";

/**
 * @constructor
 * @param {String|Object} selector
 * @param {Object|null} config
 */
export default function JSuggest (selector, args=null)
{
    if (!(this instanceof JSuggest)) return new JSuggest(selector, config)
    if(!setup(selector, args)) return;
    bindEvents();
    suggestCache.addInstance(elms.source.dataset.randid, this);

}
JSuggest.prototype.destroy= function(){
    destroy(); 
    return this
};

JSuggest.prototype.focus= function(){
    focus(); 
    return this
};
JSuggest.prototype.destroy= function(){
    destroy(); 
    return this
};
JSuggest.prototype.disable= function(){
    disable(); 
    return this
};
JSuggest.prototype.enable= function(){
    enable(); 
    return this
};
JSuggest.prototype.clearItems= function(){
    clearItems(); 
    return this
};
JSuggest.prototype.clearValues= function(){
    clearValues(); 
    return this
};
JSuggest.prototype.setValue= function(){
    setValue(); 
    return this
};
JSuggest.prototype.update= function(){
    update(); 
    return this
};
JSuggest.prototype.copy= function(){
    copy(); 
    return this
};
JSuggest.prototype.paste= function(){
    paste(); 
    return this
};
JSuggest.prototype.getInstance= function(){
    return cache.get(el)
};
JSuggest.prototype.getSource= function(){
    return elms.source;
};

JSuggest.cache= suggestCache;
