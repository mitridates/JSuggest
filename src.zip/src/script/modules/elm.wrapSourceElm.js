import createElement from "./elm.createElement.js";
import {elms, config} from "./globals.js";

export default function wrapSourceElement()
{

    let 
        /**
         * @var {HTMLElement} src 
         */
        src= elms.source,
        parentNode =   src.parentNode,
        dropdown= createElement("div", {
            class: 'jsuggest'
        }),
        falseGroup= createElement("div", {
            class: 'input-group',
        }),
/*         falseGroup_append= createElement("div", {
            class: 'input-group-append',
        }), */
/*         falseClear= createElement("span", {
            class: 'input-group-text cursor-pointer',
            style: {cursor: 'pointer'},
            html: '&times;',
        }), */
        falseInput= createElement("input", {
            class: 'jsuggest-false-input form-control',
            placeholder: config.placeholder,
            type: 'search'
        }),
        dropdowncontent= createElement("div", {
            class: 'jsuggest-content'
        }),
        container= createElement("div", {
            class: 'autocomplete',
        }),
        /**
         * dropdown input HTMLElement
         * @type {HTMLElement}
         */
        realInput = createElement('input', {
            placeholder: config.searchPlaceholder.replace("minLength", config.minLen),
            class: 'jsuggest-real-input form-control',
            tabindex:-1,
            autocomplete:"off",
            autocorrect: "off",
            autocapitalize: "off",
            spellcheck: "false",
            type: 'search',
            role: "textbox"
        })

    //bypass html5 validation to false input
    falseInput.required= src.required
    src.required= false

    container.style.display= 'none'

    //---
    falseGroup.appendChild(falseInput)
    //falseGroup_append.appendChild(falseClear)
    //falseGroup.appendChild(falseGroup_append)
    //---
    //set custom dropdown width
    if(config.width){
        createElement(dropdown, {
            style: {width: config.width}
        })
    }
    //--
    src.style.display= 'none'
    dropdowncontent.style.display= 'none'
    dropdown.appendChild(src)
    dropdown.appendChild(falseGroup)
    dropdowncontent.appendChild(realInput)
    dropdowncontent.appendChild(container)
    dropdown.appendChild(dropdowncontent)
    parentNode.appendChild(dropdown)
    
    src.setAttribute("data-jsuggest", 'true');
    
    //No funciona... por?
    let rect= falseInput.getBoundingClientRect();
    container.style.width= rect.width+'px';
    //realInput.width= falseInput.width = rect.width;
    
    elms.container= container;
    elms.dropdown= dropdown;
    elms.dropdowncontent= dropdowncontent;
    //elms.falseClear= falseClear;
    elms.falseInput= falseInput;
    elms.parentNode= parentNode;
    elms.realInput= realInput;
}