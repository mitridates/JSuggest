import { elms} from "./globals.js";
import createElement from "./elm.createElement.js";
import { clearItems } from "./item.js";

/**
 * Clear view and autocomplete state
 */
export function clearValues(){
    createElement(elms.falseInput, {
        value: '',
        title: '',
        idx: ''
    })
    if(elms.source.nodeName.toLowerCase() ==='select'){
        elms.source.options.length = 0
    }else{/**is input*/
    elms.source.value = ''
    elms.source.title= ''
    }
    clearItems()
}
