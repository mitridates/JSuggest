import { config } from "./globals.js";

/**
 * Filter static JsonApiSpec array 
 * @param {string} text
 * @return {JsonApiManager}
  */
export function filter(text)
{
    let fetch,i, spec, ret, l,
    defaults={
        /**
         * @param {JsonApiSpec} a
         * @param {string} b
         */        
        filterCb: (spec, txt)=>{//true if found
        return spec.toString().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,"").indexOf(txt.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,""))!==-1;
        },
        /**
        * @param {JsonApiSpec} a
        * @param {JsonApiSpec} b
        */
        sortCb: function(a, b) {
        return a.toString().localeCompare(b.toString());//ASC
        }
    };

    fetch= (function (f,d) {
            return {
                parsed: f instanceof JsonApiManager ? [...f] : [...f.data],
                filterCb: f.hasOwnProperty('filterCb') ? f.filterCb:d.filterCb,
                sortCb: f.hasOwnProperty('sortCb') ? f.sortCb:d.sortCb
            };
      })(config.fetch, defaults)

      i=fetch.parsed.length;

    while (i--) {
        spec= fetch.parsed[i];
        if(!fetch.filterCb(fetch.parsed[i], text)) fetch.parsed.splice(i, 1);
    }

    fetch.parsed.sort(fetch.sortCb);   

    ret = new JsonApiManager([]);
    l= fetch.parsed.length;
    ret['ret']= fetch.parsed;
    ret['length']= l;
    ret['is_parsed']= true;
    ret['resource']= 'collection'
    ret['meta']={
        "pagination":{
            currentPage: 1,
            currentPageRows: l,
            itemsPerPage: l,
            limit: l,
            limits: [0, l],
            offset: 0,
            totalPages: 1,
            totalRows: l
        }
    }
    return ret;
}