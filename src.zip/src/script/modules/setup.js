import {makeCopy} from "./copy.js";
import {elms, setEnv, setConfig} from "./globals.js";
import wrapSourceElement from "./elm.wrapSourceElm.js";
import setFalseInput from "./elm.setFalseInput.js";
import syncAttributes from "./elm.syncAttributes.js";
import observeMutations from "./elm.observeMutations.js";

export default function setup(selector, args)
{
    let src= null;
    if ( !selector ) {
        throw new Error("You must supply either a HTMLInputElement, HTMLSelectElement or a CSS3 selector string.");
    } else if (typeof selector === 'string'){
        src = document.querySelector(selector)
    }else if ( selector.nodeType ){
        if(selector.getAttribute("data-jsuggest")){//already a jsuggest element
            return false;
        }
        src= selector
    }

    if (!src) throw new Error("JSuggest element not found.");
    if (!/^(?:input|select)$/i.test(src.nodeName.toLowerCase())) throw new Error("The element is not a HTMLInputElement or HTMLSelectElement.");
    src.setAttribute('data-randid', Math.random().toString(36).slice(2));
    elms.source= src;
    elms.copy= makeCopy(src);
    setEnv();
    setConfig(args, src);
    wrapSourceElement(src);
    setFalseInput(elms.falseInput, src);
    syncAttributes();
    observeMutations()
    return true;
}
