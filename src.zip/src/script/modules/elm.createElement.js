/**
 * Basic create/modify HTMLElement
 * @param {string|HTMLElement} e
 * @param  {Object} [a]
 * @return HTMLElement
 */
export default function createElement(e, a) {
    let i, j;
    if(typeof e === "string") return createElement(document.createElement(e), a)
    if (a && "[object Object]" === Object.prototype.toString.call(a)) {
        for (i in a){
            if (i in e){
                if("style" === i){
                    for (j in a[i]){
                        e.style[j] = a[i][j];
                    }
                }else{
                    e[i] = a[i];
                }
            }else if ("html" === i){
                e.innerHTML = a[i];
            }else if("textcontent" === i){
                e.textContent = a[i];
            }else{
                e.setAttribute(i, a[i]);
            }
        }
    }
    return e;
}