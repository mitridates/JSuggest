/**
 * @todo jsdoc
 * @var {JSON} vars
 * @var {XMLHttpRequest|null} vars.req Current request if any
 * @var {bool} vars.isOpen suggest is open
 * @var {int} vars.selected selected item
 * @var {int} vars.keypressCounter control redrawing autocomplete multiple times after the last key press
 * @var {function|undefined} vars.debounceTimer timeout
 * @var {array} vars.items timeout
 */
export let vars={
    req:null,
    isOpen:null,
    selected:null,
    keypressCounter:0,
    debounceTimer:undefined, 
    items:[]
};

export let env={
    isMobileDevice:null,
    isMobileFirefox:null,
    keyUpEventName:null,    
};

export function setEnv()
{
env.isMobileDevice=  /Android|webOS|iPhone|iPad|BlackBerry|Windows Phone|Opera Mini|IEMobile|Mobile/i.test(navigator.userAgent);
env.isMobileFirefox=  env.isMobileDevice &&  navigator.userAgent.indexOf("Firefox");
env.keyUpEventName = env.isMobileFirefox ? "input" : "keyup";
}



/**
 * @constant {Object} elms
 */
export const elms= {
    /** @prop {HTMLElement} */source:null,
    /** @prop {HTMLElement} */copy: null,
    /** @prop {HTMLElement} */parentNode: null,
    /** @prop {HTMLElement} */dropdown: null,
    /** @prop {HTMLElement} */falseInput: null,
    /** @prop {HTMLElement} */dropdowncontent: null,
    /** @prop {HTMLElement} */container: null,
    /** @prop {HTMLElement} */realInput: null,
    /** @prop {HTMLElement} */falseClear: null,
};

/**
 * @constant {Object} config
 */
export const config= {
    /**  Sets the width of the container */
    width: null,
    /**
     * Fetch from JsonApiManager
     * fetch: JsonApiManager
     * 
     * Fetch from JsonApiManager with options
     * fetch: {
     *      data: JsonApiManager
     *      filter: function(spec, txt){},//filter JsonApiSpec return bool
     *      sortFn: fn(a,b), //return Array.sort(sortFn)
     * }
     * Data format: [{label: x, value: y}, {...}, ...]
     * <pre>
     * Fetch local data:
     * 
     * JSuggest.(selector, {fetch:JsonApiManager)})
     *
     * JSuggest.(selector, {fetch:{jam:JsonApiManager, filter:filterCallback, sortFn:sortFnCallback}})
     * </pre>
     */
    fetch:null,
    /**
    * //Fetch from url:
    * JSuggest.(selector, {path: urlToFetchData, method: 'post'})
    * 
    * JSuggest.(selector, urlToFetchData) // default method POST
    * 
    * </pre>
    */
    path: null,
    method: 'POST',
    debounceWaitMs: 300,
    minLen: 3,
    // maxHeight: 180,
    noResults: "Sin resultados...",
    placeholder: '',
    searchPlaceholder: "minLength caracteres para buscar ...",
    showOnFocus: false,
    /**show empty msg or nothing*/
    showNoResultMsg: true,
    /** Enables/ disables the container */
    disabled: false,
};

/**
 * @param {JSON|null} data 
 * @param {HTMLInputElement|HTMLSelectElement} src 
 */
export function setConfig(data, src) {
    let key, found; 

    //config in argguments || dataset
    for(key in config){
        if((found = src.getAttribute('data-'+key))){
            config[key]= found
        }
        if(data && data.hasOwnProperty(key)) config[key]= data[key]
    }
}