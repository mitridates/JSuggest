import l from "./event.listeners.js";
/**
 * Clear view and autocomplete state
 */
export default function focus() 
{
    l.falseInputFocusListener();
}