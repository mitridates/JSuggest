import l from "./event.listeners.js";
import { elms, env } from "./globals.js";
export default function bindEvents() 
{
    // setup event handlers
    elms.container.addEventListener("focus", l.containerFocusListener);
   // elms.falseClear.addEventListener("click", l.falseClearClickListener);
    elms.falseInput.addEventListener('search', l.falseClearClickListener);//nuevo
    elms.falseInput.addEventListener('focus', l.falseInputFocusListener);
    elms.falseInput.addEventListener('change', l.falseInputChangeListener)
    elms.realInput.addEventListener("keydown", l.realInputKeydownListener);
    elms.realInput.addEventListener(env.keyUpEventName, l.realInputKeyupListener);
    elms.realInput.addEventListener("blur", l.realInputBlurListener);
    elms.realInput.addEventListener("focus", l.realInputFocusListener);
    elms.container.addEventListener('focus', l.containerFocusListener)
    elms.container.addEventListener('containerMousedown', l.containerMousedownListener)
}