import { elms } from "./globals.js";
import l from "./event.listeners.js";
/**
 * Clear view and autocomplete state
 */
export default function enable() 
{
    elms.falseInput.disabled = false;
    elms.falseInput.addEventListener('focus', l.falseInputFocusListener);
}