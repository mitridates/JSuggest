import disable from "./suggest.disable.js";
import enable from "./suggest.enable.js";
import { clearValues } from "./suggest.clear.js";
import {elms} from "./globals.js";
/**
 * Observe hidden field to enable/disable false input if required
 */
export default function observeMutations()
{
    let el= elms.source,
        nodeobserver= new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.attributeName === "disabled") {
                    if(el.disabled){
                        disable();
                        clearValues();
                    }else{
                        enable();
                    }
                }
            });
        });
        
    nodeobserver.observe(el, {
        attributes: true
    });
}