 import { elms, vars, config } from "./globals.js";
 import listeners from "./event.listeners.js";
 import {renderItem, clearItems, styleSelected} from './item.js';

 /**
 * Redraw the autocomplete div element with suggestions
 */
 export default function update() {
    let
        container= elms.container,
        fragment = document.createDocumentFragment(),
        div;

    container.style.display='block'

    // delete all children from autocomplete DOM container
    while (container.firstChild) {
        container.removeChild(container.firstChild);
    }

    vars.items.forEach(function (item, index) {
        div = renderItem(item, index);
        if (div) {
            div.addEventListener("click", listeners.itemClickListener);
            fragment.appendChild(div);
        }
    });

    container.appendChild(fragment);
    if (vars.items.length < 1) {
        if (config.noResults) {
            let empty = document.createElement("div");
            empty.className = "empty";
            empty.textContent = config.noResults;
            container.appendChild(empty);
        } else {
            clearItems()
            return;
        }
    }else{
        styleSelected()
    }
    vars.isOpen=true
}