import { vars, elms } from "./globals.js";
import JSuggestCache from  "./cache.js";
import createElement from "./elm.createElement.js";
import listeners from "./event.listeners.js";
/**
 * @todo doc data
 * @param {string|HTMLSelectElement|HTMLInputElement} el
 * @param {Object} data
 */
function setNodeElementValue(el, data)
{
    let type = el.nodeName.toLowerCase()

    if(type === 'select'){
        el.length = 0
        el.appendChild(createElement('option', {
            value: data.id,
            text: data.value,
            selected: 'selected'
        }))
    }else if(type === 'input'){
        createElement(el, {
            value: data.id,
            title: data.value + '. ' + data.id
        })
    }
}

/**
 * @todo hacer un evento para modificar retornar div con formatos...
 * @param {JsonApiSpec} spec
 * @param {int} index
 * @return {HTMLElement}
 */
export function renderItem(spec, index) {
    let el,
        ret= spec.toString(),
        tpl= JSuggestCache.getTemplate(spec)    
    ;
    
    /**
     * @type {Element}
     */
    el= createElement('div', {
        // 'data-jsuggest': JSON.stringify(spec),
        // html:  html,
        style:{
            'font-size': '.7em'
        },
        idx: spec.get('id'),
        'data-index': index,
        tabIndex:-1
    })

    if(tpl){
        return tpl.getItem(el, index)
    }else{
        el.appendChild(document.createTextNode(ret))
        return el
    }
}

export function selectPrev() {
    let i;
    if (vars.items.length < 1) {
        vars.selected = undefined;
    }
    else {
        if (vars.selected === vars.items[0]) {
            vars.selected = vars.items[vars.items.length - 1];
        }
        else {
            for (i = vars.items.length - 1; i > 0; i--) {
                if (vars.selected === vars.items[i] || i === 1) {
                    vars.selected = vars.items[i - 1];
                    break;
                }
            }
        }
    }
}
/**
 * Select the next item in suggestions
 */
export function selectNext() {
    if (vars.items.length < 1) {
        vars.selected = undefined;
    }
    if (!vars.selected || vars.selected === vars.items[vars.items.length - 1]) {
        vars.selected = vars.items[0];
        return;
    }
    for (let i = 0; i < (vars.items.length - 1); i++) {
        if (vars.selected === vars.items[i]) {
            vars.selected = vars.items[i + 1];
            break;
        }
    }
}

export function styleSelected() {
    let sel;

    elms.container.childNodes.forEach(function (el) {
        el.classList.remove('selected')
        if(el.getAttribute('idx')===vars.selected.get('id')){
            el.classList.add('selected')
            sel= el;
        }

    });

    elms.realInput.removeEventListener("blur", listeners.realInputBlurListener);
    if(sel) sel.focus()
    elms.realInput.addEventListener("blur", listeners.realInputBlurListener);
    elms.realInput.focus()
}

/**
 * @param {JsonApiSpec} spec
 */
export function setItemValue(spec) 
{

        if(!(spec instanceof JsonApiSpec)){
            throw new Error ('Invalid argument. expected instance of JsonApiSpec, got ' + typeof spec)
        }
        if(vars.selected!== spec) vars.selected= spec

        let tpl= JSuggestCache.getTemplate(spec)


        let e= createElement(elms.falseInput, {
            value: spec.toString(),
            title: spec.toString() + '. ' + spec.id,
            idx: spec.id
        })

        if(tpl){
            tpl.setInput(e)
        }

        setNodeElementValue(elms.source, {id: spec.id, value: spec.toString()})
    }

    export function clearItems() 
{
    vars.items.length=0;
    vars.keypressCounter++
    vars.selected = undefined
    while (elms.container.firstChild) {
        elms.container.removeChild(elms.container.lastChild);
    }
    elms.falseInput.tabIndex= 0
    elms.realInput.tabIndex = -1
    elms.container.style.display='none'
    vars.isOpen=false
}