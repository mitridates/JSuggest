import { elms, config, vars } from "./globals.js";
import {clearItems} from "./item.js";
import disable from './suggest.disable.js';
import enable from './suggest.enable.js';
/**
 * Clear view and autocomplete state
 */
export default function syncAttributes() {
    let val,
    src= elms.source,
    type= src.nodeName.toLowerCase(),
    finput= elms.falseInput,
    disabled= src.disabled;

    if(type === 'select'){
        if(src.selectedIndex>-1){
            val= src[src.selectedIndex].value
        }else{
            val = ''
        }
    }else{//type === 'input'
        val = src.value
    }

    if(val===''){
        finput.value = ''
    }

    config.disabled =disabled

    if (disabled) {
        if (vars.isOpen) {
            clearItems();
        }
        disable();
    } else {
        enable();
    }
}