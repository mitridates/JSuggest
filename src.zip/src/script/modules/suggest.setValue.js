import { vars , elms} from "./globals.js";
import setSourceValue from "./elm.setSourceValue.js";
import JSuggestCache from "./cache.js";
/**
* @param {JsonApiSpec} spec
*/
export default  function setValue(spec){

   if(!(spec instanceof JsonApiSpec)){
       throw new Error ('Invalid argument. expected instance of JsonApiSpec, got ' + typeof spec)
   }
   if(vars.selected!== spec) vars.selected= spec

   let tpl= JSuggestCache.getTemplate(spec)


   let e= createElement(elms.falseInput, {
       value: spec.toString(),
       title: spec.toString() + '. ' + spec.id,
       idx: spec.id
   })

   if(tpl){
       tpl.setInput(e)
   }

   setSourceValue({id: spec.id, value: spec.toString()})
}
