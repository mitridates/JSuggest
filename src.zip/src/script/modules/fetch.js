import {elms, config, vars} from "./globals.js";
import update from "./suggest.update.js";
import {clearItems} from "./item.js";
import { filter } from "./filter.js";
/** Clear debouncing timer if assigned */
export function clearDebounceTimer() {
    if (vars.debounceTimer) window.clearTimeout(vars.debounceTimer)
}

/**
 * @param {int} trigger
 */
export default function startFetch(trigger/*1== Focus, 0== other input Keyboard */) 
{

    // if multiple keys were pressed, before we get update from server,
    // this may cause redrawing our autocomplete multiple times after the last key press.
    // to avoid this, the number of times keyboard was pressed will be
    // saved and checked before redraw our autocomplete box.
    
    
    let val= elms.realInput.value, 
    savedKeypressCounter= ++vars.keypressCounter;

    if (val.length >= config.minLen || trigger === 1 /* Focus */) {

        clearDebounceTimer();

        vars.debounceTimer = window.setTimeout(function () 
        {
            /**
             * fetchCallback
             * @param {JsonApiSpec[]} JsonApiArr
             */
            let fetchCallback= function (JsonApiArr) {
                if (vars.keypressCounter === savedKeypressCounter && JsonApiArr) {
                    vars.items=JsonApiArr;
                    vars.selected = JsonApiArr.length? JsonApiArr[0] : undefined;
                    update();
                }
            }
            if(config.path){
                fetchXhr(val, fetchCallback , 0 /* Keyboard */)
            }else if(config.fetch){
                vars.items= filter(val).getParsed();
                vars.selected=vars.items.length? vars.items[0]: undefined;
                update();
            }else{
                console.log('Nada que buscar');
            }
            


        }, trigger === 0 /* Keyboard */ ? config.debounceWaitMs : 300);
    }
    else {
        clearItems();
    }
}

/**
 * xhttp
 * @param text
 * @param fetchCallback
 */
export function fetchXhr(text, fetchCallback, trigger) {
    let
        path = config.path,
        res, jam, xhr
    ;

    // abort request while typing
    try {vars.req.abort(); } catch(e){}
    //new request
    vars.req = xhr =  new XMLHttpRequest()
    //responseType='json' ante una excepción sólo devuelve status y statusText
    //lo malo. En dev te resta información
    //lo bueno. En prod no muestra errores internos
    xhr.responseType='json'

    xhr.onload = () => {
        if (xhr.status >= 200 && xhr.status < 300) {
            res= xhr.response
            //para debug comentar xhr.responseType='json' y descomentar aquí
            //  res= xhr.response.hasOwnProperty('data')? xhr.response : JSON.parse(xhr.response),
            jam= new JsonApiManager(res.data, res.included)
            fetchCallback(jam.getParsed());
        } else {
            //para debug, descomentar aquí y arriba
            // if(window.JError){
            //     JError(xhr).show()
            // }else{
            alert(`Error ${xhr.status} : ${xhr.statusText}`)
            // }_re
        }
    };

    if(config.method === 'GET') //set queryString
    {
        xhr.open('GET', path+`?term=${text.toLowerCase()}`)
        xhr.send();
    }else{
        xhr.open('POST', path)
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.send(`term=${text.toLowerCase()}`);
    }
}