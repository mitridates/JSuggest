import { elms } from "./globals.js";
import l from "./event.listeners.js";
/**
 * Clear view and autocomplete state
 */
export default function disable() {
    elms.falseInput.disabled = true
    elms.falseInput.removeEventListener('focus', l.falseInputFocusListener)
}