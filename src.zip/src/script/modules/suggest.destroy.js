import {elms, vars} from "./globals.js";
import l from "./event.listeners.js";
import { clearDebounceTimer } from "./fetch.js";
import {clearItems} from "./item.js";
/**
 * @param {HTMLInputElement|HTMLSelectElement} elm 
 * @param {HTMLInputElement|HTMLSelectElement} cp 
 * @returns void
 */
export default function destroy()
{
    vars.keyUpEventName
    elms.realInput.removeEventListener("focus", l.realInputFocusListener);
    elms.realInput.removeEventListener("keydown", l.realInputKeydownListener);
    elms.realInput.removeEventListener(vars.keyUpEventName, l.realInputKeyupListener);
    elms.realInput.removeEventListener("blur", l.realInputBlurListener);
    elms.container.removeEventListener('focus', l.containerFocusListener)
    elms.container.removeEventListener('mousedown', l.containerMousedownListener)
    //elms.falseClear.removeEventListener('click', l.falseClearClickListener)//viejo
    elms.falseInput.removeEventListener('search', l.falseClearClickListener);//nuevo

    //window.removeEventListener("resize", resizeEventHandler);//@todo
   // document.removeEventListener("scroll", scrollEventHandler, true);//@todo
    clearDebounceTimer();
    clearItems();
    if(this) return this;
}
