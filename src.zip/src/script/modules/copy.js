import {elms} from "./globals.js"
/**
 * @param {HTMLInputElement|HTMLSelectElement} elm 
 * @param {HTMLInputElement|HTMLSelectElement} cp 
 * @returns void
 */
export function restoreCopy(elm, cp){
    if(elm.nodeName.toLowerCase()==='select')
    {
        elm.innerHTML = cp
    }else{/**is input*/
    elm.value = cp
    elm.title= ''
    }
}

 /**
 * cloneNode is a live copy so...
 * @param {HTMLElement} elm 
 * @returns {HTMLSelectElement|string}
 */
  export function makeCopy(elm){
    if(elm.nodeName.toLowerCase()==='select'){
        return elm.innerHTML
    }else{/**is input*/
        return elm.value
    }
}
