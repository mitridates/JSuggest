import { elms } from "./globals.js";
/**
*
* @param {string|HTMLSelectElement|HTMLInputElement} el
* @param {Object} data
*/
export default function setSourceValue(data){
   let src= elms.source,
   type = elms.source.nodeName.toLowerCase()

   if(type === 'select'){
    src.length = 0
    src.appendChild(createElement('option', {
           value: data.id,
           text: data.value,
           selected: 'selected'
       }))
   }else if(type === 'input'){
       createElement(src, {
           value: data.id,
           title: data.value + '. ' + data.id
       })
   }
}
